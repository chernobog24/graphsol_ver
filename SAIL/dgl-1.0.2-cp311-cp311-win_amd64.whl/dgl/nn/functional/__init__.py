"""Functions related to DGL NN Modules."""

from ...ops import edge_softmax
