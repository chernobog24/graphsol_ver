"""Gluon layer for graph related softmax."""
# pylint: disable= unused-import
from ..functional import edge_softmax
