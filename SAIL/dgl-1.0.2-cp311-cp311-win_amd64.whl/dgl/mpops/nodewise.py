"""Operators for aggregating/reducing edge data to node data."""
